-- Configuración para ejecución estable de script largo:
SET SESSION net_read_timeout = 1800;
SET SESSION net_write_timeout = 1800;
SET SESSION wait_timeout = 1800;
SET SQL_SAFE_UPDATES = 0;

USE venta_autos; 

-- Antes de duplicar la tabla, le asignamos un ID por cada venta:
ALTER TABLE registros ADD COLUMN id_venta INT FIRST;
ALTER TABLE registros MODIFY COLUMN id_venta INT NOT NULL AUTO_INCREMENT, ADD PRIMARY KEY (id_venta);

-- 1) Crear una tabla duplicada para aplicar las limpiezas:
USE venta_autos;
CREATE TABLE registros_limpios AS SELECT * FROM registros;

-- 2) Verificar la duplicación correcta:
SELECT count(*) from venta_autos.registros_limpios;
-- Esperado: 558837 registros


-- ======================================================================================================================================================================================-- ===========================================================================================================================
-- LIMPIEZA COLUMNA 2: AÑO
SELECT * FROM venta_autos.registros_limpios;
-- 1) Validar el rango de años presentes en la columna:
SELECT DISTINCT anio
FROM venta_autos.registros
ORDER BY anio ASC;
-- Resultado esperado: valores entre 1982 y 2015

-- 2) Verificar si existen registros con valores vacíos en la columna:
SELECT anio
FROM registros
WHERE anio = '';
-- Resultado esperado: 0 registros vacíos

-- 3) Cambiar el tipo de dato de la columna `anio` de VARCHAR a INT:
ALTER TABLE venta_autos.registros_limpios
MODIFY COLUMN anio INT;

-- ======================================================================================================================================================================================-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 3: MARCA
-- 1) Verificar la cantidad de registros en blanco
SELECT marca, COUNT(*) 
FROM venta_autos.registros
WHERE marca = '';
-- Resultado: 10.301 registros en blanco

-- 2) Reemplazar los registros en blanco por NULL
UPDATE venta_autos.registros_limpios
SET marca = NULL
WHERE marca = '';

-- 3) Validar que los registros en blanco fueron convertidos a NULL
SELECT marca, COUNT(*)
FROM venta_autos.registros_limpios
WHERE marca IS NULL
GROUP BY marca;
-- Resultado esperado: 10.301 registros con valor NULL

-- 4) Exploración de valores únicos en marca
SELECT marca, COUNT(*) 
FROM venta_autos.registros
GROUP BY marca
ORDER BY marca DESC;
-- Objetivo: detectar errores de escritura, duplicados y variantes

-- 5) Verificar la cantidad de valores únicos antes de normalizar
SELECT COUNT(DISTINCT marca)
FROM venta_autos.registros;
-- Resultado: 67 marcas diferentes (algunas mal escritas o duplicadas)

-- 6) Homogeneizar variantes de nombres de marcas
UPDATE venta_autos.registros_limpios
SET marca = CASE
    WHEN marca = 'vw' THEN 'Volkswagen'
    WHEN marca IN ('mercedes-b', 'mercedes') THEN 'Mercedes-Benz'
    WHEN marca = 'mazda tk' THEN 'Mazda'
    WHEN marca = 'landrover' THEN 'Land Rover'
    WHEN marca = 'hyundai tk' THEN 'Hyundai'
    WHEN marca = 'gmc truck' THEN 'GMC'
    WHEN marca IN ('ford truck', 'ford tk') THEN 'Ford'
    WHEN marca = 'dodge tk' THEN 'Dodge'
    WHEN marca = 'chev truck' THEN 'Chevrolet'
    ELSE marca
END;

-- 7) Verificar los cambios aplicados:
SELECT marca, COUNT(*) 
FROM venta_autos.registros_limpios
GROUP BY marca
ORDER BY marca DESC;

-- 8) Validar la cantidad de valores únicos después de normalizar:
SELECT COUNT(DISTINCT marca)
FROM venta_autos.registros_limpios;
-- Resultado esperado: 55 marcas distintas

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 4: MODELO
-- 1) Verificar cuántos registros tienen valor en blanco:
SELECT modelo,
count(*) 
FROM venta_autos.registros
WHERE modelo='';
-- Resultado esperado: 10399 registros en blanco

-- 2) Reemplazar valores en blanco por NULL en la tabla limpia:
UPDATE venta_autos.registros_limpios
SET modelo = NULL
where modelo = ''; 

-- 3) Verificar que los registros en blanco fueron correctamente convertidos a NULL:
SELECT modelo,
count(*)
FROM venta_autos.registros_limpios
WHERE modelo is NULL
GROUP BY modelo; 

-- 4) Análisis exploratorio de las variables: frecuencia
SELECT modelo,
COUNT(*)
FROM venta_autos.registros
GROUP BY modelo
ORDER BY modelo;

-- 5) Análisis exploratorio de las variables: Total QTY modelos
SELECT COUNT(distinct modelo)
from venta_autos.registros;
-- Resultado: 852 modelos distintos

-- 6) Identificar modelos más vendidos por marca
SELECT marca,
modelo,
count(*) AS cantidad
FROM venta_autos.registros_limpios
WHERE marca is not NULL and modelo is not NULL
GROUP BY marca, modelo
ORDER BY cantidad DESC
LIMIT 10; 
-- Para estas marcas, vamos a verificar cuales son todos los modelos disponibles, y evaluaremos o no normalizar los nombres.

-- 7) Exploración específica de los modelos más frecuentes:
SELECT modelo,
COUNT(*)
FROM venta_autos.registros_limpios
WHERE marca IN ('Ford','Chevrolet','Nissan','Toyota','Honda','Dodge','Bmw')
GROUP BY modelo
ORDER BY modelo; 
-- Tenemos 288 modelos distintos para las 7 marcas mas vendidas. Hemos considerado no realizar la limpieza de esta columna porque hemos verificado que hay una gran cantidad de variables distintas por cada modelo. No se lanzará el código de limpieza en esta etapa por limitaciones de tiempo, ya que no es viable evaluar todas las casuísticas posibles. Para el análisis en Power BI, se priorizarán las variables con mayor volumen de registros y que no presenten errores en los nombres.

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 6: TIPO DE CARROCERÍA
-- 1) Análisis exploratorio de las variables:
SELECT tipo_carroceria, COUNT(*) AS total
FROM venta_autos.registros
GROUP BY tipo_carroceria
ORDER BY total DESC; 
-- Hemos detectado una categoria que no corresponde como tipo de carroceria y que tiene 26 ventas (Navitgation).

-- 2) Detección de los valores en blanco:
SELECT COUNT(*) AS blancos
FROM venta_autos.registros
WHERE tipo_carroceria = ''; 
-- Resultado: 13195 valores en blanco.

-- 3) Exploración de registros de la categoría errónea:
SELECT *
FROM venta_autos.registros
WHERE tipo_carroceria='Navitgation'; 
-- El motivo de esta categoría como tipo de carrocería se debe a un desfase de una columna hacia la derecha en la estructura de esos registros. Por esta razón, se decidió eliminarlos de la tabla limpia para evitar inconsistencias en el análisis. 

-- 4) Depuración de categoría errónea: 'Navitgation'
DELETE FROM venta_autos.registros_limpios
WHERE tipo_carroceria = 'Navitgation';

-- 5) Reemplazo de valores en blanco por NULL
UPDATE venta_autos.registros_limpios
SET tipo_carroceria = NULL
WHERE tipo_carroceria='';

-- 6) Reagrupación de categoría en categoría estandarizada:
UPDATE venta_autos.registros_limpios
SET tipo_carroceria = CASE
    WHEN tipo_carroceria IN (
        'convertible', 'beetle convertible', 'g convertible', 'g37 convertible',
        'q60 convertible', 'granturismo convertible'
    ) THEN 'Convertible'
    
    WHEN tipo_carroceria IN (
        'q60 coupe', 'coupe', 'g coupe', 'elantra coupe', 'genesis coupe',
        'cts coupe', 'cts-v coupe', 'g37 coupe', 'koup'
    ) THEN 'Coupe'
    
    WHEN tipo_carroceria = 'hatchback' THEN 'Hatchback'
    
    WHEN tipo_carroceria = 'minivan' THEN 'Minivan'
    
    WHEN tipo_carroceria IN (
        'cab plus 4', 'mega cab', 'xtracab', 'club cab', 'cab plus',
        'regular-cab', 'quad cab', 'regular cab', 'supercab', 'extended cab',
        'supercrew', 'crew cab', 'double cab', 'crewmax cab', 'access cab', 'king cab'
    ) THEN 'Pickup'
    
    WHEN tipo_carroceria = 'suv' THEN 'SUV'
    
    WHEN tipo_carroceria IN ('sedan', 'g sedan') THEN 'Sedan'
    
    WHEN tipo_carroceria IN (
        'ram van', 'promaster cargo van', 'e-series van', 'van', 'transit van'
    ) THEN 'Van'
    
    WHEN tipo_carroceria IN (
        'tsx sport wagon', 'cts-v wagon', 'cts wagon', 'wagon'
    ) THEN 'Wagon'
    
    ELSE tipo_carroceria 
END;

-- 7) Verificación final de categorías tras la limpieza:
SELECT tipo_carroceria, COUNT(*) AS total
FROM venta_autos.registros_limpios
GROUP BY tipo_carroceria
ORDER BY total DESC;

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 7: CAJA
-- 1) Análisis exploratorio de las variables:
SELECT caja, COUNT(*) AS total
FROM venta_autos.registros
GROUP BY caja
ORDER BY total DESC; 
-- Resultado: 26 ventas de 'Sedan', esta no es una categoría válida como tipo de caja, en la tabla limpia no la veremos porque es producto del desfazaje explicado anteriormente.

-- 2) Detección de los valores en blanco:
SELECT COUNT(*) AS blancos
FROM venta_autos.registros
WHERE caja = ''; 
-- Resultado: 65352 registros en blanco.

-- 3) Reemplazo de valores en blanco por NULL
UPDATE venta_autos.registros_limpios
SET caja = NULL
WHERE caja = '';

-- 4) Cambio de idioma en categoría:
UPDATE venta_autos.registros_limpios
SET caja = 'automatico'
WHERE caja = 'automatic';

-- 5) Verificación final de categorías tras la limpieza:
SELECT caja, COUNT(*) AS total
FROM venta_autos.registros_limpios
GROUP BY caja
ORDER BY total DESC;

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 8: NUMERO DE IDENTIFICACIÓN
-- 1) Verificar duplicidades:
SELECT numero_identificacion,
COUNT(*)
FROM venta_autos.registros
GROUP BY numero_identificacion
HAVING COUNT(*)>1; 
-- Resultado: Algunos están duplicados (el número de identificación corresponde al bastidor del coche)

-- 2) Total de bastidores duplicados: 
WITH columna_nueva as (SELECT numero_identificacion,
COUNT(*)
FROM venta_autos.registros
GROUP BY numero_identificacion
HAVING COUNT(*)>1)
Select count(*)
FROM columna_nueva; 
-- Resultado: 8328 numeros de identificación duplicados. 

-- 3) Análisis de duplicados:
SELECT *
FROM venta_autos.registros
WHERE numero_identificacion IN (
    SELECT numero_identificacion
    FROM venta_autos.registros
    GROUP BY numero_identificacion
    HAVING COUNT(*) > 1
)
ORDER BY numero_identificacion ASC; 
-- Tras un análisis preliminar, se observó que aunque los vehículos tienen las mismas características (marca, modelo, color, año, etc.), corresponden a ventas diferentes. Esto sugiere que podrían tratarse de operaciones internas, como transferencias entre concesionarias, y no necesariamente duplicados erróneos.

-- 4) Análisis de duplicidad por coincidencia completa de columnas:
SELECT 
    anio,marca,modelo,designacion_adicional,tipo_carroceria,caja,numero_identificacion,lugar_venta,estado_vehiculo, kilometros,color_exterior,color_interior,vendedor,valor_mercado_usd,valor_venta_usd,fecha_venta,
    COUNT(*) AS cantidad
FROM venta_autos.registros
GROUP BY 
    anio,marca,modelo,designacion_adicional,tipo_carroceria,caja,numero_identificacion,lugar_venta, estado_vehiculo, kilometros,color_exterior,color_interior,vendedor,valor_mercado_usd,valor_venta_usd,fecha_venta
HAVING COUNT(*) > 1; 
-- Resultado: 0 ventas duplicadas.

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 9: LUGAR DE VENTA
-- 1) Análisis exploratorio:
SELECT lugar_venta,
COUNT(*)
FROM venta_autos.registros 
GROUP BY lugar_venta; 
-- La mayoría de los registros corresponden a estados de EE.UU., junto con cuatro provincias de Canadá y Puerto Rico.

-- 2) Detección de los valores en blanco:
SELECT COUNT(*) AS blancos
FROM venta_autos.registros
WHERE lugar_venta = ''; 
-- Resultado: 0 registros en blanco.

-- 3) Filtrado de registros fuera del alcance geográfico del análisis:
SELECT lugar_venta,
count(*)
FROM venta_autos.registros
where lugar_venta in ('qc','ab','on','pr','ns')
group by lugar_venta 

UNION ALL

SELECT 'TOTAL', COUNT(*)
FROM venta_autos.registros
WHERE lugar_venta IN ('qc','ab','on','pr','ns'); 
-- Resultado: 8401 ventas realizadas fuera de Estados Unidos. Dado que estos registros no se encuentran dentro del alcance geográfico definido para este análisis, se ha decidido excluirlos del conjunto de datos.

-- 4) Eliminación de registros correspondientes a ubicaciones fuera de EE.UU.
DELETE FROM venta_autos.registros_limpios
WHERE lugar_venta IN ('qc', 'ab', 'on', 'pr', 'ns');

-- 5) Transformación de siglas de estados a nombres completos:
UPDATE venta_autos.registros_limpios
SET lugar_venta = CASE 
    WHEN lugar_venta = 'CA' THEN 'California'
    WHEN lugar_venta ='TX' THEN 'Texas'
    WHEN lugar_venta ='PA' THEN 'Pennsylvania'
    WHEN lugar_venta ='MN' THEN 'Minnesota'
    WHEN lugar_venta ='AZ' THEN 'Arizona'
    WHEN lugar_venta ='WI' THEN 'Wisconsin'
    WHEN lugar_venta ='TN' THEN 'Tennessee'
    WHEN lugar_venta ='MD' THEN 'Maryland'
    WHEN lugar_venta ='FL' THEN 'Florida'
    WHEN lugar_venta ='NE' THEN 'Nebraska'
    WHEN lugar_venta ='NJ' THEN 'New Jersey'
    WHEN lugar_venta ='NV' THEN 'Nevada'
    WHEN lugar_venta ='OH' THEN 'Ohio'
    WHEN lugar_venta ='MI' THEN 'Michigan'
    WHEN lugar_venta ='GA' THEN 'Georgia'
    WHEN lugar_venta ='VA' THEN 'Virginia'
    WHEN lugar_venta ='SC' THEN 'South Carolina'
    WHEN lugar_venta ='NC' THEN 'North Carolina'
    WHEN lugar_venta ='IN' THEN 'Indiana'
    WHEN lugar_venta ='IL' THEN 'Illinois'
    WHEN lugar_venta ='CO' THEN 'Colorado'
    WHEN lugar_venta ='UT' THEN 'Utah'
    WHEN lugar_venta ='MO' THEN 'Missouri'
    WHEN lugar_venta ='NY' THEN 'New York'
    WHEN lugar_venta ='MA' THEN 'Massachusetts'
    WHEN lugar_venta ='OR' THEN 'Oregon'
    WHEN lugar_venta ='LA' THEN 'Louisiana'
    WHEN lugar_venta ='WA' THEN 'Washington'
    WHEN lugar_venta ='HI' THEN 'Hawaii'
    WHEN lugar_venta ='OK' THEN 'Oklahoma'
    WHEN lugar_venta ='MS' THEN 'Mississippi'
    WHEN lugar_venta ='NM' THEN 'New Mexico'
    WHEN lugar_venta ='AL' THEN 'Alabama'
    ELSE lugar_venta
END; 

-- 6) Verificación final tras limpieza
SELECT lugar_venta,
COUNT(*)
FROM venta_autos.registros_limpios 
GROUP BY lugar_venta
ORDER BY COUNT(*) DESC;

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 10: ESTADO VEHICULO
-- 1) Análisis exploratorio de las variables:
SELECT estado_vehiculo, COUNT(*) AS total
FROM venta_autos.registros
GROUP BY estado_vehiculo
ORDER BY total DESC; 
-- Resultado: la clasificación es de 1 a 49 y que hay celdas en blanco.

-- 2) Detección de valores en blanco:
SELECT COUNT(*)
FROM venta_autos.registros
WHERE estado_vehiculo=''; 
-- Resultado: 11820 registros blancos

-- 3) Reemplazo de valores en blanco por NULL
UPDATE venta_autos.registros_limpios
SET estado_vehiculo = NULL
WHERE estado_vehiculo = '';

-- 4) Detección tipo de dato:
DESCRIBE venta_autos.registros;
-- Resultado: VARCHAR

-- 5) Cambio del tipo de dato a INT:
ALTER TABLE venta_autos.registros_limpios
MODIFY COLUMN estado_vehiculo INT;

-- 6) Habilitamos nueva columna para reasignación de nuevas categorías:
ALTER TABLE venta_autos.registros_limpios
ADD COLUMN estado_vehiculo_categoria VARCHAR(255)
AFTER estado_vehiculo;
-- estado_vehiculo_categoria es la nueva columna

-- Configuración para ejecución estable de script largo:
SET SESSION net_read_timeout = 1800;
SET SESSION net_write_timeout = 1800;
SET SESSION wait_timeout = 1800;
SET SQL_SAFE_UPDATES = 0;

-- 7) Asignación de nueva categoría: 
-- Necesita mantenimiento importante
UPDATE venta_autos.registros_limpios
SET estado_vehiculo_categoria = 'Necesita mantenimiento importante'
WHERE estado_vehiculo BETWEEN 1 AND 10;

-- Malo
UPDATE venta_autos.registros_limpios
SET estado_vehiculo_categoria = 'Malo'
WHERE estado_vehiculo BETWEEN 11 AND 20;

-- Aceptable
UPDATE venta_autos.registros_limpios
SET estado_vehiculo_categoria = 'Aceptable'
WHERE estado_vehiculo BETWEEN 21 AND 30;

-- Bueno
UPDATE venta_autos.registros_limpios
SET estado_vehiculo_categoria = 'Bueno'
WHERE estado_vehiculo BETWEEN 31 AND 40;

-- Muy bueno
UPDATE venta_autos.registros_limpios
SET estado_vehiculo_categoria = 'Muy bueno'
WHERE estado_vehiculo BETWEEN 41 AND 48;

-- Excelente
UPDATE venta_autos.registros_limpios
SET estado_vehiculo_categoria = 'Excelente'
WHERE estado_vehiculo IN (49, 50);

-- 8) Validación de cambios tras limpieza
SELECT estado_vehiculo_categoria, COUNT(*) AS total
FROM venta_autos.registros_limpios
GROUP BY estado_vehiculo_categoria
ORDER BY total DESC; 

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 11: KILOMETROS
-- 1) Detección de registros en blanco
SELECT kilometros, COUNT(*) 
FROM venta_autos.registros 
WHERE kilometros = '';
-- Resultado: 94 registros en blanco

-- 2) Reemplazo de valores en blanco por NULL:
UPDATE venta_autos.registros_limpios
SET kilometros=NULL
where kilometros='';

-- 3) Verificamos el cambio a NULL:
SELECT kilometros,
count(*)
FROM venta_autos.registros_limpios
WHERE kilometros IS NULL
GROUP BY kilometros;

-- 4) Detección tipo de dato de la columna kilometros:
DESCRIBE venta_autos.registros;
-- Resultado: VARCHAR

-- 5) Cambio del tipo de dato a BIGINT:
ALTER TABLE venta_autos.registros_limpios
MODIFY COLUMN kilometros BIGINT;

-- 6) Analisis exploratorio de la columna:
SELECT MAX(kilometros) as valor_maximo,
MIN(kilometros) as valor_minimo,
AVG(kilometros) as promedio,
STDDEV(kilometros) as desviacion
FROM venta_autos.registros_limpios;
-- Resultado: valor maximo 999999 (veremos si es coherente), valor min. 1, promedio 68320 y desv estandar= 53398. 

-- 7) Segmentamos los valores de 'kilometros' en categorías por rangos:
SELECT 
  CASE 
    WHEN kilometros BETWEEN 0 AND 1000 THEN '0-1.000'
    WHEN kilometros BETWEEN 1001 AND 99999 THEN '1001-99.999'
    WHEN kilometros BETWEEN 100000 AND 199999 THEN '100.000-199.999'
    WHEN kilometros BETWEEN 200000 AND 299999 THEN '200.000-299.999'
    WHEN kilometros BETWEEN 300000 AND 399999 THEN '300.000-399.999'
    WHEN kilometros BETWEEN 400000 AND 499999 THEN '400.000-499.999'
    WHEN kilometros BETWEEN 500000 AND 599999 THEN '500.000-599.999'
    WHEN kilometros BETWEEN 600000 AND 699999 THEN '600.000-699.999'
    WHEN kilometros BETWEEN 700000 AND 799999 THEN '700.000-799.999'
    WHEN kilometros BETWEEN 800000 AND 899999 THEN '800.000-899.999'
    WHEN kilometros BETWEEN 900000 AND 999999 THEN '900.000-999.999'
    ELSE '1000000 o más'
  END AS rango_km,
    COUNT(*) AS cantidad
FROM venta_autos.registros
GROUP BY rango_km
ORDER BY rango_km ASC;
-- Resultado: 2674 registros con menos de 1000km y 74 registros con más de 900000. Exploraremos estos 2 rangos con mas en profundidad.

-- 8) Análisis del rango '0-1000km':
SELECT kilometros,
COUNT(*)
FROM venta_autos.registros
WHERE kilometros<=1000
GROUP BY kilometros
ORDER BY kilometros ASC;
-- Resultado: Detectamos valores atípicos en el kilometraje: 1.318 registros con valor 1, 29 con 10 y 3 con 100. Dado que el análisis se enfoca en vehículos de segunda mano, se considera que los registros con menos de 1.000 km no son coherentes y se reemplazan por NULL.

-- 9) Reemplazo de rango '0-1000km' por NULL:
UPDATE venta_autos.registros_limpios
SET kilometros = NULL
where kilometros <= 1000;

-- 10) Análisis del rango '> 90000km':
SELECT kilometros,
COUNT(*)
FROM venta_autos.registros
WHERE kilometros > 900000
GROUP BY kilometros
ORDER BY kilometros ASC;
-- Resultado: De los 74 registros con más de 900.000 km, 72 presentan el valor 999.999. Al considerarse poco realista para vehículos de segunda mano, se reemplazan por NULL

-- 11) Reemplazo de valor '999999' por NULL:
UPDATE venta_autos.registros_limpios
SET kilometros = NULL
where kilometros = 999999;

-- 12) Validamos la eliminación de valores atípicos:
SELECT *
FROM venta_autos.registros_limpios
WHERE kilometros IN (1,999999); 

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 12: COLOR EXTERIOR
-- 1) Analisis exploratorio de la columna:
SELECT color_exterior,
COUNT(*)
FROM venta_autos.registros
GROUP BY color_exterior; 
-- Resultado: Los valores numéricos detectados provienen de registros desfasados. Al eliminar las filas donde tipo_carroceria = 'Navigation', dichos valores desaparecen por completo.

-- 2) Normalización de valores inválidos en la columna:
UPDATE venta_autos.registros_limpios
SET color_exterior = NULL
WHERE color_exterior IN ('','â€”'); 
-- Resultado: Cambiamos los registros en blanco y  â€” por NULL. En total son 25434 registros.

-- 3) Traducimos los colores al castellano:
UPDATE venta_autos.registros_limpios
SET color_exterior = CASE
    WHEN color_exterior = 'white' THEN 'blanco'
    WHEN color_exterior = 'gray' THEN 'gris'
    WHEN color_exterior = 'black' THEN 'negro'
    WHEN color_exterior = 'red' THEN 'rojo'
    WHEN color_exterior = 'silver' THEN 'plateado'
    WHEN color_exterior = 'blue' THEN 'azul'
    WHEN color_exterior = 'brown' THEN 'marrón'
    WHEN color_exterior = 'beige' THEN 'beige'
    WHEN color_exterior = 'purple' THEN 'púrpura'
    WHEN color_exterior = 'burgundy' THEN 'burdeos'
    WHEN color_exterior = 'gold' THEN 'dorado'
    WHEN color_exterior = 'yellow' THEN 'amarillo'
    WHEN color_exterior = 'green' THEN 'verde'
    WHEN color_exterior = 'charcoal' THEN 'gris_oscuro'
    WHEN color_exterior = 'orange' THEN 'naranja'
    WHEN color_exterior = 'off-white' THEN 'blanco_opaco'
    WHEN color_exterior = 'turquoise' THEN 'turquesa'
    WHEN color_exterior = 'pink' THEN 'rosa'
    WHEN color_exterior = 'lime' THEN 'lima'
    ELSE color_exterior  
END; 

-- 4) Verificamos el cambio tras la limpieza:
SELECT color_exterior,
COUNT(*)
FROM venta_autos.registros_limpios
GROUP BY color_exterior; 

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 13: COLOR INTERIOR
-- 1) Analisis exploratorio de la columna:
SELECT color_interior,
COUNT(*)
FROM venta_autos.registros
GROUP BY color_interior; 
-- Se detectó un valor inválido en la columna con el carácter â€”. Junto con los valores en blanco, será reemplazado por NULL.

-- 2) Normalización de valores inválidos en la columna:
UPDATE venta_autos.registros_limpios
SET color_interior=NULL
WHERE color_interior IN ('','â€”'); 
-- Resultado: cambiamos los registros en blanco y  â€” por NULL. Total: 17825 registros.

-- 3) Traducimos los registros al castellano:
UPDATE venta_autos.registros_limpios
SET color_interior = CASE 
    WHEN color_interior ='black' THEN 'negro'
    WHEN color_interior ='beige' THEN 'beige'
    WHEN color_interior ='tan' THEN 'tostado'
    WHEN color_interior ='gray' THEN 'gris'
    WHEN color_interior ='brown' THEN 'marrón'
    WHEN color_interior ='burgundy' THEN 'burdeos'
    WHEN color_interior ='white' THEN 'blanco'
    WHEN color_interior ='silver' THEN 'plateado'
    WHEN color_interior ='off-white' THEN 'blanco_opaco'
    WHEN color_interior ='blue' THEN 'azul'
    WHEN color_interior ='red' THEN 'rojo'
    WHEN color_interior ='yellow' THEN 'amarillo'
    WHEN color_interior ='green' THEN 'verde'
    WHEN color_interior ='purple' THEN 'púrpura'
    WHEN color_interior ='orange' THEN 'naranja'
    WHEN color_interior ='gold' THEN 'dorado'
    ELSE color_interior 
END; 

-- 4) Verificamos el cambio tras la limpieza:
SELECT color_interior,
COUNT(*)
FROM venta_autos.registros_limpios
GROUP BY color_interior; 

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 15: VALOR MERCADO
-- 1) Detección de valores en blanco:
SELECT valor_mercado_usd,
count(*)
FROM venta_autos.registros
WHERE valor_mercado_usd=''; 
-- Resultado: 38 registros en blanco

-- 2) Reemplazo de valores en blanco por NULL: 
UPDATE venta_autos.registros_limpios
SET valor_mercado_usd = NULL
where valor_mercado_usd = '';

-- 3) Verificamos el cambio de los valores en blanco: 
SELECT valor_mercado_usd,
count(*)
FROM venta_autos.registros_limpios
WHERE valor_mercado_usd IS NULL
GROUP BY valor_mercado_usd; 
-- Resultado: 12 registros. La diferencia se debe a los 26 registros eliminados anteriormente por el desfase.

-- 4) Detección tipo de dato de la columna valor_mercado:
DESCRIBE venta_autos.registros;
-- Resultado: VARCHAR

-- 5) Cambio del tipo de dato a BIGINT:
ALTER TABLE venta_autos.registros_limpios
MODIFY COLUMN valor_mercado_usd BIGINT; 

-- 6) Analisis exploratorio de la columna:
SELECT MAX(valor_mercado_usd) as valor_maximo,
MIN(valor_mercado_usd) as valor_minimo,
AVG(valor_mercado_usd) as promedio,
STDDEV(valor_mercado_usd) as desviacion
FROM venta_autos.registros_limpios; 
-- Resultado: valor maximo: 182000 USD, valor minimo: 25 USD, promedio: 13769 USD, desv. estandard: 9679.9 USD.

-- 7) Distribución del valor de mercado por rangos:
SELECT 
  CASE 
	WHEN valor_mercado_usd BETWEEN 0 AND 300 THEN '0-300'
    WHEN valor_mercado_usd BETWEEN 301 AND 1000 THEN '300-1.000'
    WHEN valor_mercado_usd BETWEEN 1000 AND 10000 THEN '1001-10.000'
    WHEN valor_mercado_usd BETWEEN 10001 AND 30000 THEN '10.001-30.000'
    WHEN valor_mercado_usd BETWEEN 30001 AND 60000 THEN '30.001-60.000'
    WHEN valor_mercado_usd BETWEEN 60001 AND 90000 THEN '60.001-90.000'
    WHEN valor_mercado_usd BETWEEN 90001 AND 120000 THEN '90.001-120.000'
    WHEN valor_mercado_usd BETWEEN 120001 AND 150000 THEN '120.001-150.000'
    WHEN valor_mercado_usd BETWEEN 150001 AND 185000 THEN '150.001-185.000'
    END AS rango_valor_mercado,
COUNT(*) AS cantidad
FROM venta_autos.registros
GROUP BY rango_valor_mercado
ORDER BY rango_valor_mercado ASC; 
-- Resultado: Se identificaron 695 vehículos con un valor de mercado inferior a 300 USD. La mayoría se concentra en el rango de 1.000 a 30.000 USD. A continuación, se analizan los valores extremos.

-- 8) Análisis de rango '< 300': 
SELECT valor_mercado_usd,
COUNT(*)
FROM venta_autos.registros
WHERE valor_mercado_usd <= 300
GROUP BY valor_mercado_usd
ORDER BY valor_mercado_usd ASC; 
-- Vemos cuantos autos hay por cada valor en la banda 0-300 USD

-- 9) Análisis de coherencia entre valor de mercado y año de fabricación:
SELECT valor_mercado_usd, 
anio
FROM venta_autos.registros
WHERE valor_mercado_usd <=300; 
-- La mayoría de los vehículos en este rango de precio fueron fabricados entre 1990 y 2007, lo cual, a priori, resulta coherente con un valor de mercado reducido.

-- 10) Análisis de rango '> 150000': 
SELECT valor_mercado_usd,
COUNT(*)
FROM venta_autos.registros
WHERE valor_mercado_usd >= 150000
GROUP BY valor_mercado_usd
ORDER BY valor_mercado_usd ASC; 
-- Revisamos cuantos autos hay con valor de mercado por encima de 150.000 usd.

-- 11) Validación de valores de mercado elevados:
SELECT valor_mercado_usd, 
anio,
marca
FROM venta_autos.registros
WHERE valor_mercado_usd >= 150000; 
-- Los registros con valor de mercado >= 150000 USD corresponden a marcas premium y modelos recientes, por lo que se consideran valores coherentes.

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 16: VALOR VENTA
-- 1) Detección de valores en blanco:
SELECT valor_venta_usd,
count(*)
FROM venta_autos.registros
WHERE valor_venta_usd=''; 
-- Resultado: 12 registros en blanco

-- 2) Reemplazo de valores en blanco por NULL:
UPDATE venta_autos.registros_limpios
SET valor_venta_usd=NULL
where valor_venta_usd='';

-- 3) Verificamos el cambio de los valores en blanco: 
SELECT valor_venta_usd,
count(*)
FROM venta_autos.registros_limpios
WHERE valor_venta_usd IS NULL
GROUP BY valor_venta_usd; 

-- 4) Detección tipo de dato de la columna valor_mercado:
DESCRIBE venta_autos.registros;
-- Resultado: VARCHAR

-- 5) Cambio del tipo de dato a BIGINT:
ALTER TABLE venta_autos.registros_limpios
MODIFY COLUMN valor_venta_usd BIGINT; 

-- 6) Analisis exploratorio de la columna:
SELECT MAX(valor_venta_usd) as valor_maximo,
MIN(valor_venta_usd) as valor_minimo,
AVG(valor_venta_usd) as promedio,
STDDEV(valor_venta_usd) as desviacion
FROM venta_autos.registros_limpios; 
-- Resultado: valor maximo: 230000 USD, valor minimo: 1 USD, promedio: 13611 USD, desv. estandard: 9749.5 USD.

-- 7) Distribución del valor de venta por rangos:
SELECT 
  CASE 
	WHEN valor_venta_usd BETWEEN 0 AND 300 THEN '0-300'
    WHEN valor_venta_usd BETWEEN 301 AND 1000 THEN '300-1.000'
    WHEN valor_venta_usd BETWEEN 1000 AND 10000 THEN '1001-10.000'
    WHEN valor_venta_usd BETWEEN 10001 AND 30000 THEN '10.001-30.000'
    WHEN valor_venta_usd BETWEEN 30001 AND 60000 THEN '30.001-60.000'
    WHEN valor_venta_usd BETWEEN 60001 AND 90000 THEN '60.001-90.000'
    WHEN valor_venta_usd BETWEEN 90001 AND 120000 THEN '90.001-120.000'
    WHEN valor_venta_usd BETWEEN 120001 AND 150000 THEN '120.001-150.000'
    WHEN valor_venta_usd BETWEEN 150001 AND 250000 THEN '150.001-250.000'
    END AS rango_valor_venta,
COUNT(*) AS cantidad
FROM venta_autos.registros
GROUP BY rango_valor_venta
ORDER BY rango_valor_venta ASC; 
-- Resultado: 2055 autos de menos de 300 USD de valor de venta. La mayoria de los autos se vendieron en la banda 1.000-30.000. Vamos a analizar los extremos.

-- 8) Análisis de rango '< 300': 
SELECT valor_venta_usd,
COUNT(*)
FROM venta_autos.registros
WHERE valor_venta_usd <= 300
GROUP BY valor_venta_usd
ORDER BY valor_venta_usd ASC; 
-- Vemos cuantos autos hay por cada valor en la banda 0-300 USD

-- 9) Análisis de rango '< 300': 
SELECT valor_mercado_usd,
valor_venta_usd, 
anio
FROM venta_autos.registros
WHERE valor_venta_usd <=300; 
-- Comparamos para cada venta de <300 USD el año de fabricación y el valor de mercado. La mayoria se encuentra en el rango 1990-2007, y si bien en algunos casos hay diferencia con el valor de mercado, puede deberse al estado del vehículo.

-- 10) Validación de valores de venta elevados:
SELECT valor_mercado_usd,
valor_venta_usd, 
anio
FROM venta_autos.registros
WHERE valor_venta_usd >=150000; 
-- En todos menos uno (230000) hay coherencia entre el valor de venta, el valor de mercado y el año. Vamos a ver que pasa con el registro de 230000

-- 11) Análisis puntual del outlier con valor de venta de 230.000 USD:
SELECT *
FROM venta_autos.registros
WHERE valor_venta_usd = 230000; 
-- Teniendo en cuenta el modelo del auto, el año de fabricación y el precio de mercado (22.800) se deduce que el precio de venta es 23.000 usd.

-- 12) Corregimos el precio de este registro a 23.000 usd.:
SET SQL_SAFE_UPDATES = 0;
UPDATE venta_autos.registros_limpios
SET valor_venta_usd = 23000
WHERE valor_venta_usd = 230000;

-- 13) Validamos cambios tras limpieza:
SELECT valor_mercado_usd,
valor_venta_usd, 
anio
FROM venta_autos.registros_limpios
WHERE valor_venta_usd >=150000;

-- ======================================================================================================================================================================================
-- LIMPIEZA COLUMNA 17: FECHA VENTA
-- 1) Detección del formato fecha:
SELECT fecha_venta, COUNT(*) AS total
FROM venta_autos.registros
GROUP BY fecha_venta
ORDER BY total DESC; 
-- ejemplo del formato de la columna: 'Tue Feb 10 2015 01:30:00 GMT-0800 (PST)'

-- 2) Análisis exploratorio:
SELECT COUNT(*) AS blancos
FROM venta_autos.registros
WHERE fecha_venta = ''; 
-- Resultado: 12 registros en blanco

-- 3) Reemplazo de valores en blanco por NULL:
SET SQL_SAFE_UPDATES = 0;
UPDATE venta_autos.registros_limpios
SET fecha_venta = NULL
WHERE fecha_venta = '';

-- 4) Validación por longitud de caracteres
SELECT fecha_venta,
LENGTH(fecha_venta)
FROM venta_autos.registros; 
-- Resultado: Se confirma que la longitud estándar es de 39 caracteres.

SELECT fecha_venta
FROM venta_autos.registros
WHERE LENGTH(fecha_venta)!=39; 
-- Se verificó si existían registros con una longitud de caracteres distinta al valor esperado. La consulta devolvió 38 resultados: 12 correspondían a registros en blanco y 26 a registros con un desfase de una columna, los cuales fueron eliminados en la tabla limpia.

-- 5) Transformación de fechas a formato DATE:
ALTER TABLE venta_autos.registros_limpios
ADD COLUMN fecha_venta_nuevo DATE; 
--  Añadimos columna auxiliar de fecha_venta_nuevo con el formato correcto

UPDATE venta_autos.registros_limpios
SET fecha_venta_nuevo = DATE(STR_TO_DATE(
  SUBSTRING_INDEX(fecha_venta, 'GMT', 1),
  '%a %b %d %Y %H:%i:%s'
)); -- transformamos la fecha de formato original a formato DATE 

-- 6) Validamos cambios hechos tras limpieza:
SELECT fecha_venta_nuevo,
count(*)
FROM venta_autos.registros_limpios
GROUP BY fecha_venta_nuevo;

SET SQL_SAFE_UPDATES = 1;



